"""Dependency-free wheelhouse sentinel used by the Code demo."""

__version__ = "0.0.0"
