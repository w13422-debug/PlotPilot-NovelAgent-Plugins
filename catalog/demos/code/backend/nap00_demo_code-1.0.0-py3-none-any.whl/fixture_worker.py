"""Deterministic NAP-00 Code demo entrypoint."""

DEFAULT_RESULT = {"echo": "nap00", "fixture": "code", "value": 1}


def main(payload=None):
    """Return a deterministic artifact payload for the contract fixture."""
    if payload is None:
        return dict(DEFAULT_RESULT)
    if not isinstance(payload, dict):
        raise TypeError("payload must be a mapping")
    return {
        "echo": payload.get("echo", "nap00"),
        "fixture": "code",
        "value": payload.get("value", 1),
    }
